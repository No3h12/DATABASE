import streamlit as st
import socket

st.title("Master DB Controller")

# Form inputs
query = st.text_area("Write your SQL query:", height=150)
host = st.text_input("Master IP Address", value="127.0.0.1")
port = st.number_input("Port", value=9000)

# Send query
if st.button("Execute Query"):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((host, port))
            s.sendall((query + "\n").encode())
            result = s.recv(4096).decode()
        st.success("Response from Master:")
        st.code(result)
    except Exception as e:
        st.error(f"Failed to connect or send: {e}")
