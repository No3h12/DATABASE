package main

import (
    "bufio"
    "database/sql"
    "fmt"
    "log"
    "net"
    "strings"

    _ "github.com/go-sql-driver/mysql"
)

const (
    HOST     = "0.0.0.0"
    PORT     = "9000"
    USER     = "root"
    PASSWORD = "root"
)

func handleConnection(conn net.Conn, db *sql.DB) {
    defer conn.Close()
    reader := bufio.NewReader(conn)

    query, err := reader.ReadString('\n')
    if err != nil {
        fmt.Println("Failed to read query:", err)
        return
    }

    query = strings.TrimSpace(query)
    fmt.Println("Received query:", query)

    rows, err := db.Query(query)
    if err != nil {
        msg := "Query error: " + err.Error() + "\n"
        conn.Write([]byte(msg))
        return
    }
    defer rows.Close()

    // Get column names
    columns, err := rows.Columns()
    if err != nil {
        conn.Write([]byte("Error reading columns\n"))
        return
    }

    // Prepare values
    values := make([]sql.RawBytes, len(columns))
    scanArgs := make([]interface{}, len(values))
    for i := range values {
        scanArgs[i] = &values[i]
    }

    var output strings.Builder
    output.WriteString(strings.Join(columns, "\t") + "\n")

    for rows.Next() {
        err = rows.Scan(scanArgs...)
        if err != nil {
            conn.Write([]byte("Row scan error\n"))
            return
        }

        for _, col := range values {
            if col == nil {
                output.WriteString("NULL\t")
            } else {
                output.WriteString(string(col) + "\t")
            }
        }
        output.WriteString("\n")
    }

    conn.Write([]byte(output.String()))
}

func main() {
    // Connect to MariaDB (local)
    dsn := fmt.Sprintf("%s:%s@tcp(127.0.0.1:3306)/", USER, PASSWORD)
    db, err := sql.Open("mysql", dsn)
    if err != nil {
        log.Fatal("DB connection error:", err)
    }
    defer db.Close()

    listener, err := net.Listen("tcp", HOST+":"+PORT)
    if err != nil {
        log.Fatal("TCP listen error:", err)
    }
    defer listener.Close()
    fmt.Printf("Master server listening on %s:%s\n", HOST, PORT)

    for {
        conn, err := listener.Accept()
        if err != nil {
            log.Println("Connection accept error:", err)
            continue
        }
        go handleConnection(conn, db)
    }
}
