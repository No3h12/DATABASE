package main

import (
    "bufio"
    "database/sql"
    "fmt"
    "log"
    "net"
    "strings"
    _ "github.com/go-sql-driver/mysql"
)

const (
    masterAddress = "0.0.0.0:9000" // الماستر بيستقبل على البورت ده
    dbUser        = "root"
    dbPassword    = "root"
    dbName        = "bank_db"
)

func handleConnection(conn net.Conn, db *sql.DB) {
    defer conn.Close()

    reader := bufio.NewReader(conn)
    for {
        query, err := reader.ReadString('\n')
        if err != nil {
            fmt.Println("Client disconnected:", err)
            return
        }

        query = strings.TrimSpace(query)
        if query == "" {
            continue
        }

        fmt.Println("Received query:", query)

        // تنفيذ الكويري
        _, err = db.Exec(query)
        if err != nil {
            conn.Write([]byte("Error: " + err.Error() + "\n"))
        } else {
            conn.Write([]byte("Query executed successfully\n"))
        }
    }
}

func main() {
    // الاتصال بقاعدة البيانات في الماستر
    dsn := fmt.Sprintf("%s:%s@/%s", dbUser, dbPassword, dbName)
    db, err := sql.Open("mysql", dsn)
    if err != nil {
        log.Fatal("Database connection error:", err)
    }
    defer db.Close()

    // التأكد من الاتصال شغال
    err = db.Ping()
    if err != nil {
        log.Fatal("Database not reachable:", err)
    }

    // بدء السيرفر
    listener, err := net.Listen("tcp", masterAddress)
    if err != nil {
        log.Fatal("Failed to start server:", err)
    }
    defer listener.Close()

    fmt.Println("Master server listening on", masterAddress)

    for {
        conn, err := listener.Accept()
        if err != nil {
            fmt.Println("Failed to accept connection:", err)
            continue
        }

        go handleConnection(conn, db) // concurrency باستخدام goroutine
    }
}
